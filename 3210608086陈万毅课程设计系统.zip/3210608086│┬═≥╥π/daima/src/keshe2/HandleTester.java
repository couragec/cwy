package keshe2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HandleTester implements ActionListener {
    View.Teacherview.viewTeacherAndAdministrator.viewTester viewTester;

    @Override
    public void actionPerformed(ActionEvent e) {
        String id= viewTester.id.getText();
        String name= viewTester.name.getText();
        String age= viewTester.age.getText();
        String laboratory= viewTester.laboratory.getText();
        String job= viewTester.job.getText();
        String sex = "";
        if(viewTester.man.isSelected()){
            sex=sex+ viewTester.man.getText();
        }else if(viewTester.woman.isSelected()){
            sex=sex+ viewTester.woman.getText();
        }

        if(id.length()==0||name.length()==0||age.length()==0||laboratory.length()==0||job.length()==0|| sex.length()==0)
            return;
        Table.tableTester tableTester = new Table.tableTester();
        Insert.insertTester insertTester= new Insert.insertTester();
        tableTester.setId(id);
        tableTester.setName(name);
        tableTester.setSex(sex);
        tableTester.setAge(age);
        tableTester.setLaboratory(laboratory);
        tableTester.setJob(job);
        int isOK=insertTester.insert(tableTester);
        if(isOK!=0){
            JOptionPane.showMessageDialog(new View.Teacherview.viewTeacherAndAdministrator.viewTester(),"添加成功！","提示",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(new View.Teacherview.viewTeacherAndAdministrator.viewTester(),"添加失败，该实验员可能已存在！","提示",JOptionPane.WARNING_MESSAGE);
        }
        viewTester.id.setText("");
        viewTester.name.setText("");
        viewTester.age.setText("");
        viewTester.laboratory.setText("");
        viewTester.job.setText("");
    }
    public void setView(View.Teacherview.viewTeacherAndAdministrator.viewTester view){
        this.viewTester =view;
    }
}
