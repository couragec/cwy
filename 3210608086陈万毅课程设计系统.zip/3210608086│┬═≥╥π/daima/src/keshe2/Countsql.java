package keshe2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Countsql {
    ResultSet rs;
    public ResultSet countTeacher(){
        try {
            Connection con=ConnectDataBase.getConnection();
            Statement sta= con.createStatement();
            String sql="select * from teacher;";
            rs=sta.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet countTester(){
        try {
            Connection con=ConnectDataBase.getConnection();
            Statement sta= con.createStatement();
            String sql="select * from tester;";
            rs=sta.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet countAdministrator(){
        try {
            Connection con=ConnectDataBase.getConnection();
            Statement sta= con.createStatement();
            String sql="select * from administrator;";
            rs=sta.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
    public ResultSet countTeacherAndAdministrator(){
        try {
            Connection con=ConnectDataBase.getConnection();
            Statement sta= con.createStatement();
            String sql="select * from teacherandadministrator;";
            rs=sta.executeQuery(sql);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;
    }
}
