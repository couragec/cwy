package keshe2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlCount implements ActionListener {
    static JFrame jf=new JFrame("3210608086陈万毅统计人员信息");
    JToolBar jToolBar=new JToolBar();
    JButton add=new JButton("添加信息 ");
    JButton query=new JButton(" 查询信息 ");
    JButton show=new JButton(" 显示信息 ");
    JButton edit=new JButton(" 编辑信息 ");
    JButton delete=new JButton(" 删除信息 ");
    JButton count=new JButton(" 统计信息");

    CountView countView=new CountView();
    public void init(){
        jToolBar.add(add);
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar, BorderLayout.NORTH);
       // jf.pack();
        jf.setLocation(600,400);
        jf.add(countView);
        jf.setVisible(true);
        jf.setSize(450,400);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        init();
        addAction();
        View.jf.setVisible(false);
        ControlDelete.jf.setVisible(false);
        ControlEdit.jf.setVisible(false);
        ControlShow.jf.setVisible(false);
        ControlQuery.jf.setVisible(false);
    }
    public void addAction(){
        query.addActionListener(new ControlQuery());     //查询
        show.addActionListener(new ControlShow());       //显示
        edit.addActionListener(new ControlEdit());       //编辑
        delete.addActionListener(new ControlDelete());   //删除
        count.addActionListener(new ControlCount());     //统计
    }
}
