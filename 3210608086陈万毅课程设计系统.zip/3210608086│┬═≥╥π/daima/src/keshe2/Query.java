package keshe2;

import javax.swing.*;

public class Query {
    public static class QueryAdministratorView extends JPanel {
        JLabel QueryID=new JLabel("id");
        JTextField queryID=new JTextField(11);
        JButton queryid=new JButton("查询");
        JTextArea a1=new JTextArea(10,30);

        JLabel QueryName=new JLabel("name");
        JTextField queryName=new JTextField(11);
        JButton queryname=new JButton("查询");
        JTextArea a2=new JTextArea(10,30);

        ControlQuery.HandleQueryAdministratorID handleQueryAdministratorID;
        ControlQuery.HandleQueryAdministratorName handleQueryAdministratorName;

        public QueryAdministratorView(){
            init();
            addAction();
        }

        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(QueryID);
            h1.add(queryID);
            Box h2=Box.createHorizontalBox();
            h2.add(QueryName);
            h2.add(queryName);
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(queryid);
            v.add(a1);
            v.add(h2);
            v.add(queryname);
            v.add(a2);

            add(v);
        }

        public void addAction(){
            handleQueryAdministratorID=new ControlQuery.HandleQueryAdministratorID();
            handleQueryAdministratorID.setView(this);
            queryid.addActionListener(handleQueryAdministratorID);

            handleQueryAdministratorName=new ControlQuery.HandleQueryAdministratorName();
            handleQueryAdministratorName.setView(this);
            queryname.addActionListener(handleQueryAdministratorName);
        }
    }

    public static class QueryTeacherAndAdministratorView extends JPanel {
        JLabel QueryID=new JLabel("id");
        JTextField queryID=new JTextField(11);
        JButton queryid=new JButton("查询");
        JTextArea a1=new JTextArea(10,30);

        JLabel QueryName=new JLabel("name");
        JTextField queryName=new JTextField(11);
        JButton queryname=new JButton("查询");
        JTextArea a2=new JTextArea(10,30);

        ControlQuery.HandleQueryTeacherAndAdministratorID handleQueryTeacherAndAdministratorID;
        ControlQuery.HandleQueryTeacherAndAdministratorName handleQueryTeacherAndAdministratorName;

        public QueryTeacherAndAdministratorView(){
            init();
            addAction();
        }

        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(QueryID);
            h1.add(queryID);
            Box h2=Box.createHorizontalBox();
            h2.add(QueryName);
            h2.add(queryName);
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(queryid);
            v.add(a1);
            v.add(h2);
            v.add(queryname);
            v.add(a2);

            add(v);
        }

        public void addAction(){
            handleQueryTeacherAndAdministratorID=new ControlQuery.HandleQueryTeacherAndAdministratorID();
            handleQueryTeacherAndAdministratorID.setView(this);
            queryid.addActionListener(handleQueryTeacherAndAdministratorID);

            handleQueryTeacherAndAdministratorName=new ControlQuery.HandleQueryTeacherAndAdministratorName();
            handleQueryTeacherAndAdministratorName.setView(this);
            queryname.addActionListener(handleQueryTeacherAndAdministratorName);

        }
    }
    //老师
    public static class QueryTeacherView extends JPanel {
        JLabel QueryID=new JLabel("teacher id");
        JTextField queryID=new JTextField(11);
        JButton queryid=new JButton("编号查询");

        JTextArea a1=new JTextArea(10,30);

        JLabel QueryName=new JLabel("teacher name");
        JTextField queryName=new JTextField(11);
        JButton queryname=new JButton("姓名查询");
        JTextArea a2=new JTextArea(10,30);

        ControlQuery.HandleQueryTeacherName handleQueryTeacherName;
        ControlQuery.HandleQueryTeacherID handleQueryTeacherID;

        public QueryTeacherView(){
            init();
            addAction();
        }

        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(QueryID);
            h1.add(queryID);
            Box h2=Box.createHorizontalBox();
            h2.add(QueryName);
            h2.add(queryName);
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(queryid);
            v.add(a1);
            v.add(h2);
            v.add(queryname);
            v.add(a2);

            add(v);
        }

        public void addAction(){
            handleQueryTeacherName=new ControlQuery.HandleQueryTeacherName();
            handleQueryTeacherName.setView(this);
            queryname.addActionListener(handleQueryTeacherName);

            handleQueryTeacherID=new ControlQuery.HandleQueryTeacherID();
            handleQueryTeacherID.setView(this);
            queryid.addActionListener(handleQueryTeacherID);
        }

    }

    public static class QueryTesterView extends JPanel {
        JLabel QueryID=new JLabel("id");
        JTextField queryID=new JTextField(11);
        JButton queryid=new JButton("查询");
        JTextArea a1=new JTextArea(10,30);

        JLabel QueryName=new JLabel("name");
        JTextField queryName=new JTextField(11);
        JButton queryname=new JButton("查询");
        JTextArea a2=new JTextArea(10,30);

        ControlQuery.HandleQueryTesterID handleQueryTesterID;
        ControlQuery.HandleQueryTesterName handleQueryTesterName;

        public QueryTesterView(){
            init();
            addAction();
        }

        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(QueryID);
            h1.add(queryID);
            Box h2=Box.createHorizontalBox();
            h2.add(QueryName);
            h2.add(queryName);
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(queryid);
            v.add(a1);
            v.add(h2);
            v.add(queryname);
            v.add(a2);

            add(v);
        }

        public void addAction(){
            handleQueryTesterID=new ControlQuery.HandleQueryTesterID();
            handleQueryTesterID.setView(this);
            queryid.addActionListener(handleQueryTesterID);

            handleQueryTesterName=new ControlQuery.HandleQueryTesterName();
            handleQueryTesterName.setView(this);
            queryname.addActionListener(handleQueryTesterName);
        }
    }
}
