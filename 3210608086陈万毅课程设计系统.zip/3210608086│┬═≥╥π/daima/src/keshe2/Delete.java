package keshe2;

import javax.swing.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class Delete {
    public static class DeleteAdministrator {
        int isOK;

        public int deleteID(Table.tableAdministrator tableAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from administrator where id = '"+ tableAdministrator.getId()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }

        public int deleteName(Table.tableAdministrator tableAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from administrator where name = '"+ tableAdministrator.getName()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }

    public static class deleteAdministratorView extends JPanel {
        JLabel ID=new JLabel("id");
        JTextField id=new JTextField(11);
        JButton d1=new JButton("删除");
        JLabel Name=new JLabel("name");
        JTextField name=new JTextField(11);
        JButton d2=new JButton("删除");
        ControlDelete.HandleDeleteAdministratorName handleDeleteAdministratorName;
        ControlDelete.HandleDeleteAdministratorID handleDeleteAdministratorID;

        public deleteAdministratorView(){
            init();
            addAction();
        }

        public void init(){
            Box v=Box.createVerticalBox();
            v.add(ID);
            v.add(id);
            v.add(d1);
            v.add(Name);
            v.add(name);
            v.add(d2);
            add(v);
        }

        public void addAction(){
            handleDeleteAdministratorID=new ControlDelete.HandleDeleteAdministratorID();
            handleDeleteAdministratorID.setView(this);
            d1.addActionListener(handleDeleteAdministratorID);

            handleDeleteAdministratorName=new ControlDelete.HandleDeleteAdministratorName();
            handleDeleteAdministratorName.setView(this);
            d2.addActionListener(handleDeleteAdministratorName);
        }
    }

    public static class DeleteTeacher {
        int isOK;
        public int deleteName(Table.tableTeacher tableTeacher){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from teacher where name = '"+ tableTeacher.getName()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }

        public int deleteID(Table.tableTeacher tableTeacher){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from teacher where id = '"+ tableTeacher.getId()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }

    public static class DeleteTeacherAndAdministrator {
        int isOK;
        public int deleteName(Table.tableTeacherAndAdministrator tableTeacherAndAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from teacherandadministrator where 姓名 = '"+ tableTeacherAndAdministrator.getName()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }

        public int deleteID(Table.tableTeacherAndAdministrator tableTeacherAndAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from teacherandadministrator where 编号 = '"+ tableTeacherAndAdministrator.getId()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }

    public static class deleteTeacherAndAdministratorView extends JPanel {
        JLabel ID=new JLabel("id");
        JTextField id=new JTextField(11);
        JButton d1=new JButton("删除");
        JLabel Name=new JLabel("name");
        JTextField name=new JTextField(11);
        JButton d2=new JButton("删除");
        ControlDelete.HandleDeleteTeacherAndAdministratorID handleDeleteTeacherAndAdministratorID;
        ControlDelete.HandleDeleteTeacherAndAdministratorName handleDeleteTeacherAndAdministratorName;

        public deleteTeacherAndAdministratorView(){
            init();
            addAction();
        }

        public void init(){
            Box v=Box.createVerticalBox();
            v.add(ID);
            v.add(id);
            v.add(d1);
            v.add(Name);
            v.add(name);
            v.add(d2);
            add(v);
        }

        public void addAction(){
            handleDeleteTeacherAndAdministratorID=new ControlDelete.HandleDeleteTeacherAndAdministratorID();
            handleDeleteTeacherAndAdministratorID.setView(this);
            d1.addActionListener(handleDeleteTeacherAndAdministratorID);

            handleDeleteTeacherAndAdministratorName=new ControlDelete.HandleDeleteTeacherAndAdministratorName();
            handleDeleteTeacherAndAdministratorName.setView(this);
            d2.addActionListener(handleDeleteTeacherAndAdministratorName);
        }
    }
    //老师
    public static class deleteTeacherView extends JPanel {
        JLabel ID=new JLabel("id delete");
        JTextField id=new JTextField(11);
        JButton d1=new JButton("删除");
        JLabel Name=new JLabel("name delete");
        JTextField name=new JTextField(11);
        JButton d2=new JButton("删除");
        ControlDelete.HandleDeleteTeacherID handleDeleteTeacherID;
        ControlDelete.HandleDeleteTeacherName handleDeleteTeacherName;

        public deleteTeacherView(){
            init();
            addAction();
        }

        public void init(){
            Box v=Box.createVerticalBox();
            v.add(ID);
            v.add(id);
            v.add(d1);
            v.add(Name);
            v.add(name);
            v.add(d2);
            add(v);
        }

        public void addAction(){
            handleDeleteTeacherID=new ControlDelete.HandleDeleteTeacherID();
            handleDeleteTeacherID.setView(this);
            d1.addActionListener(handleDeleteTeacherID);

            handleDeleteTeacherName=new ControlDelete.HandleDeleteTeacherName();
            handleDeleteTeacherName.setView(this);
            d2.addActionListener(handleDeleteTeacherName);
        }
    }
    //实验员
    public static class DeleteTester {
        int isOK;
        public int deleteID(Table.tableTester tableTester){
            try {
                Connection con= ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from tester where id = '"+ tableTester.getId()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }

        public int deleteName(Table.tableTester tableTester){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="delete from tester where name = '"+ tableTester.getName()+"';";
                isOK=sta.executeUpdate(sql);
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }

    public static class deleteTesterView extends JPanel {
        JLabel ID=new JLabel("id");
        JTextField id=new JTextField(11);
        JButton d1=new JButton("删除");
        JLabel Name=new JLabel("name");
        JTextField name=new JTextField(11);
        JButton d2=new JButton("删除");
        ControlDelete.HandleDeleteTesterID handleDeleteTesterID;
        ControlDelete.HandleDeleteTesterName handleDeleteTesterName;

        public deleteTesterView(){
            init();
            addAction();
        }

        public void init(){
            Box v=Box.createVerticalBox();
            v.add(ID);
            v.add(id);
            v.add(d1);
            v.add(Name);
            v.add(name);
            v.add(d2);
            add(v);
        }

        public void addAction(){
            handleDeleteTesterID=new ControlDelete.HandleDeleteTesterID();
            handleDeleteTesterID.setView(this);
            d1.addActionListener(handleDeleteTesterID);

            handleDeleteTesterName=new ControlDelete.HandleDeleteTesterName();
            handleDeleteTesterName.setView(this);
            d2.addActionListener(handleDeleteTesterName);
        }
    }
}
