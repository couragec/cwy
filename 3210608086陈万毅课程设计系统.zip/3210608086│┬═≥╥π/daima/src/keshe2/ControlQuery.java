package keshe2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControlQuery extends Component implements ActionListener {
    //整体组装
    static JFrame jf=new JFrame("3210608086陈万毅查询人员信息");
    //
    JToolBar jToolBar=new JToolBar();
    JButton add=new JButton("-添加信息- ");
    JButton query=new JButton(" -查询信息- ");
    JButton show=new JButton(" -显示信息- ");
    JButton edit=new JButton(" -编辑信息- ");
    JButton delete=new JButton(" -删除信息- ");
    JButton count=new JButton(" -统计信息- ");
    //
    JTabbedPane jtp=new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);
    Query.QueryTeacherView queryTeacherView=new Query.QueryTeacherView();
    Query.QueryTesterView queryTesterView=new Query.QueryTesterView();
    Query.QueryAdministratorView queryAdministratorView=new Query.QueryAdministratorView();
    Query.QueryTeacherAndAdministratorView queryTeacherAndAdministratorView=new Query.QueryTeacherAndAdministratorView();
    @Override
    public void actionPerformed(ActionEvent e) {
        init();
        addAction();
       View.jf.setVisible(false);
        ControlCount.jf.setVisible(false);
        ControlDelete.jf.setVisible(false);
        ControlEdit.jf.setVisible(false);
        ControlShow.jf.setVisible(false);
    }
    public void addAction(){
        query.addActionListener(new ControlQuery());     //查询
        show.addActionListener(new ControlShow());       //显示
        edit.addActionListener(new ControlEdit());       //编辑
        delete.addActionListener(new ControlDelete());   //删除
        count.addActionListener(new ControlCount());     //统计
    }
    public void init(){
        //尝试
        jToolBar.add(add);
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar, BorderLayout.NORTH);
        //尝试
        jtp.addTab("教师",queryTeacherView);
        jtp.addTab("实验员",queryTesterView);
        jtp.addTab("行政人员",queryAdministratorView);
        jtp.addTab("教师兼行政人员",queryTeacherAndAdministratorView);
        jf.setLocation(600,400);
        jf.add(jtp);
        jf.pack();
        jf.setVisible(true);
    }

    //行政人员Id
    public static class HandleQueryAdministratorID implements ActionListener {
        Query.QueryAdministratorView queryAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Id = queryAdministratorView.queryID.getText();
            if (Id.length() == 0) return;
            Table.tableAdministrator tableAdministrator = new Table.tableAdministrator();
            Select.selectAdministrator selectAdministrator = new Select.selectAdministrator();
            tableAdministrator.setId(Id);
            ResultSet rs = selectAdministrator.queryID(tableAdministrator);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryAdministratorView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String politics = rs.getString(5);
                        String title = rs.getString(6);
                        queryAdministratorView.a1.setText("");
                        queryAdministratorView.a1.append("编号：    " + id + "\n");
                        queryAdministratorView.a1.append("姓名：    " + name + "\n");
                        queryAdministratorView.a1.append("性别：    " + sex + "\n");
                        queryAdministratorView.a1.append("年龄：    " + age + "\n");
                        queryAdministratorView.a1.append("政治面貌： " + politics + "\n");
                        queryAdministratorView.a1.append("职称：    " + title + "\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryAdministratorView(), "查询失败，该行政人员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryAdministratorView.queryID.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryAdministratorView view) {
            this.queryAdministratorView = view;
        }
    }

    public static class HandleQueryAdministratorName implements ActionListener {
        Query.QueryAdministratorView queryAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Name = queryAdministratorView.queryName.getText();
            if (Name.length() == 0) return;
            Table.tableAdministrator tableAdministrator = new Table.tableAdministrator();
            Select.selectAdministrator selectAdministrator = new Select.selectAdministrator();
            tableAdministrator.setName(Name);
            ResultSet rs = selectAdministrator.queryName(tableAdministrator);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryAdministratorView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String politics = rs.getString(5);
                        String title = rs.getString(6);
                        queryAdministratorView.a2.setText("");
                        queryAdministratorView.a2.append("编号：    " + id + "\n");
                        queryAdministratorView.a2.append("姓名：    " + name + "\n");
                        queryAdministratorView.a2.append("性别：    " + sex + "\n");
                        queryAdministratorView.a2.append("年龄：    " + age + "\n");
                        queryAdministratorView.a2.append("政治面貌： " + politics + "\n");
                        queryAdministratorView.a2.append("职称：    " + title + "\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryAdministratorView(), "查询失败，该行政人员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryAdministratorView.queryName.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryAdministratorView view) {
            this.queryAdministratorView = view;
        }
    }

    public static class HandleQueryTeacherAndAdministratorID implements ActionListener {
        Query.QueryTeacherAndAdministratorView queryTeacherAndAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Id = queryTeacherAndAdministratorView.queryID.getText();
            if (Id.length() == 0)  return;
            Table.tableTeacherAndAdministrator tableTeacherAndAdministrator = new Table.tableTeacherAndAdministrator();
            Select.selectTeacherAndAdministrator selectTeacherAndAdministrator = new Select.selectTeacherAndAdministrator();
            tableTeacherAndAdministrator.setId(Id);
            ResultSet rs = selectTeacherAndAdministrator.queryID(tableTeacherAndAdministrator);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherAndAdministratorView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String college = rs.getString(5);
                        String major = rs.getString(6);
                        String teacherTitle = rs.getString(7);
                        String politics=rs.getString(8);
                        String politicsTitle=rs.getString(9);
                        queryTeacherAndAdministratorView.a1.setText("");
                        queryTeacherAndAdministratorView.a1.append("编号：    " + id + "\n");
                        queryTeacherAndAdministratorView.a1.append("姓名：    " + name + "\n");
                        queryTeacherAndAdministratorView.a1.append("性别：    " + sex + "\n");
                        queryTeacherAndAdministratorView.a1.append("年龄：    " + age + "\n");
                        queryTeacherAndAdministratorView.a1.append("学院：    " + college + "\n");
                        queryTeacherAndAdministratorView.a1.append("专业：    " + major + "\n");
                        queryTeacherAndAdministratorView.a1.append("教师职称： " + teacherTitle+ "\n");
                        queryTeacherAndAdministratorView.a1.append("政治面貌： "+politics+"\n");
                        queryTeacherAndAdministratorView.a1.append("政治职称： "+politicsTitle+"\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherAndAdministratorView(), "查询失败，该教师兼行政人员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryTeacherAndAdministratorView.queryID.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryTeacherAndAdministratorView view) {
            this.queryTeacherAndAdministratorView = view;
        }
    }

    public static class HandleQueryTeacherAndAdministratorName implements ActionListener {
        Query.QueryTeacherAndAdministratorView queryTeacherAndAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Name = queryTeacherAndAdministratorView.queryName.getText();
            if (Name.length() == 0)  return;
            Table.tableTeacherAndAdministrator tableTeacherAndAdministrator = new Table.tableTeacherAndAdministrator();
            Select.selectTeacherAndAdministrator selectTeacherAndAdministrator = new Select.selectTeacherAndAdministrator();
            tableTeacherAndAdministrator.setName(Name);
            ResultSet rs = selectTeacherAndAdministrator.queryName(tableTeacherAndAdministrator);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherAndAdministratorView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String college = rs.getString(5);
                        String major = rs.getString(6);
                        String teacherTitle = rs.getString(7);
                        String politics=rs.getString(8);
                        String politicsTitle=rs.getString(9);
                        queryTeacherAndAdministratorView.a2.setText("");
                        queryTeacherAndAdministratorView.a2.append("编号：    " + id + "\n");
                        queryTeacherAndAdministratorView.a2.append("姓名：    " + name + "\n");
                        queryTeacherAndAdministratorView.a2.append("性别：    " + sex + "\n");
                        queryTeacherAndAdministratorView.a2.append("年龄：    " + age + "\n");
                        queryTeacherAndAdministratorView.a2.append("学院：    " + college + "\n");
                        queryTeacherAndAdministratorView.a2.append("专业：    " + major + "\n");
                        queryTeacherAndAdministratorView.a2.append("教师职称： " + teacherTitle+ "\n");
                        queryTeacherAndAdministratorView.a2.append("政治面貌： "+politics+"\n");
                        queryTeacherAndAdministratorView.a2.append("政治职称： "+politicsTitle+"\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherAndAdministratorView(), "查询失败，该教师兼行政人员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryTeacherAndAdministratorView.queryName.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryTeacherAndAdministratorView view) {
            this.queryTeacherAndAdministratorView = view;
        }
    }

    public static class HandleQueryTeacherID implements ActionListener {
        Query.QueryTeacherView queryTeacherView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Id = queryTeacherView.queryID.getText();
            if (Id.length() == 0) return;
            Table.tableTeacher tableTeacher = new Table.tableTeacher();
            Select.selectTeacher selectTeacher = new Select.selectTeacher();
            tableTeacher.setId(Id);
            ResultSet rs = selectTeacher.queryID(tableTeacher);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String college = rs.getString(5);
                        String major = rs.getString(6);
                        String title = rs.getString(7);
                        queryTeacherView.a1.setText("");
                        queryTeacherView.a1.append("编号： " + id + "\n");
                        queryTeacherView.a1.append("姓名： " + name + "\n");
                        queryTeacherView.a1.append("性别： " + sex + "\n");
                        queryTeacherView.a1.append("年龄： " + age + "\n");
                        queryTeacherView.a1.append("学院： " + college + "\n");
                        queryTeacherView.a1.append("专业： " + major + "\n");
                        queryTeacherView.a1.append("职称： " + title + "\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryTeacherView(), "查询失败，该老师不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryTeacherView.queryID.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryTeacherView view) {
            this.queryTeacherView = view;
        }
    }
    //老师名字
    public static class HandleQueryTeacherName implements ActionListener {
        Query.QueryTeacherView queryTeacherView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Name=queryTeacherView.queryName.getText();
            if(Name.length()==0)  return;
            Table.tableTeacher tableTeacher =new Table.tableTeacher();
            Select.selectTeacher selectTeacher=new Select.selectTeacher();
            tableTeacher.setName(Name);
            ResultSet rs =selectTeacher.queryName(tableTeacher);
            try {
                if(rs.next()){
                    JOptionPane.showMessageDialog(new Query.QueryTeacherView(),"查询成功！","提示",JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id=rs.getString(1);
                        String name=rs.getString(2);
                        String sex=rs.getString(3);
                        String age=rs.getString(4);
                        String college=rs.getString(5);
                        String major=rs.getString(6);
                        String title=rs.getString(7);
                        queryTeacherView.a2.setText("");
                        queryTeacherView.a2.append("编号： "+id+"\n");
                        queryTeacherView.a2.append("姓名： "+name+"\n");
                        queryTeacherView.a2.append("性别： "+sex+"\n");
                        queryTeacherView.a2.append("年龄： "+age+"\n");
                        queryTeacherView.a2.append("学院： "+college+"\n");
                        queryTeacherView.a2.append("专业： "+major+"\n");
                        queryTeacherView.a2.append("职称： "+title+"\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }else{
                    JOptionPane.showMessageDialog(new Query.QueryTeacherView(),"查询失败，该老师不存在！","提示",JOptionPane.WARNING_MESSAGE);
                    queryTeacherView.queryName.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        public void setView(Query.QueryTeacherView view){
            this.queryTeacherView=view;
        }
    }
    //实验员ID
    public static class HandleQueryTesterID implements ActionListener {
        Query.QueryTesterView queryTesterView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Id = queryTesterView.queryID.getText();
            if (Id.length() == 0) return;
            Table.tableTester tableTester = new Table.tableTester();
            Select.selectTester selectTester = new Select.selectTester();
            tableTester.setId(Id);
            ResultSet rs = selectTester.queryID(tableTester);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryTesterView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String laboratory = rs.getString(5);
                        String job = rs.getString(6);
                        queryTesterView.a1.setText("");
                        queryTesterView.a1.append("编号：  " + id + "\n");
                        queryTesterView.a1.append("姓名：  " + name + "\n");
                        queryTesterView.a1.append("性别：  " + sex + "\n");
                        queryTesterView.a1.append("年龄：  " + age + "\n");
                        queryTesterView.a1.append("实验室： " + laboratory + "\n");
                        queryTesterView.a1.append("职务：  " + job + "\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryTesterView(), "查询失败，该实验员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryTesterView.queryID.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryTesterView view) {
            this.queryTesterView = view;
        }

    }
    //实验员名字
    public static class HandleQueryTesterName implements ActionListener {
        Query.QueryTesterView queryTesterView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String Name = queryTesterView.queryName.getText();
            if (Name.length() == 0) return;
            Table.tableTester tableTester = new Table.tableTester();
            Select.selectTester selectTester = new Select.selectTester();
            tableTester.setName(Name);
            ResultSet rs = selectTester.queryName(tableTester);
            try {
                if (rs.next()) {
                    JOptionPane.showMessageDialog(new Query.QueryTesterView(), "查询成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
                    try {
                        String id = rs.getString(1);
                        String name = rs.getString(2);
                        String sex = rs.getString(3);
                        String age = rs.getString(4);
                        String laboratory = rs.getString(5);
                        String job = rs.getString(6);
                        queryTesterView.a2.setText("");
                        queryTesterView.a2.append("编号：  " + id + "\n");
                        queryTesterView.a2.append("姓名：  " + name + "\n");
                        queryTesterView.a2.append("性别：  " + sex + "\n");
                        queryTesterView.a2.append("年龄：  " + age + "\n");
                        queryTesterView.a2.append("实验室： " + laboratory + "\n");
                        queryTesterView.a2.append("职务：  " + job + "\n");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(new Query.QueryTesterView(), "查询失败，该实验员不存在！", "提示", JOptionPane.WARNING_MESSAGE);
                    queryTesterView.queryName.setText("");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        public void setView(Query.QueryTesterView view) {
            this.queryTesterView = view;
        }
    }
}
