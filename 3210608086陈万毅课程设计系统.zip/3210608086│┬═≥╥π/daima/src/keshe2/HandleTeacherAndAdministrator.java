package keshe2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HandleTeacherAndAdministrator implements ActionListener {
    View.Teacherview.viewTeacherAndAdministrator viewTeacherAndAdministrator;

    @Override
    public void actionPerformed(ActionEvent e) {
        String id= viewTeacherAndAdministrator.id.getText();
        String name= viewTeacherAndAdministrator.name.getText();
        String age= viewTeacherAndAdministrator.age.getText();
        String college= viewTeacherAndAdministrator.college.getText();
        String major= viewTeacherAndAdministrator.major.getText();
        String teacherTitle= viewTeacherAndAdministrator.teacherTitle.getText();
        String politics= viewTeacherAndAdministrator.politics.getText();
        String politicsTitle= viewTeacherAndAdministrator.politicsTitle.getText();
        String sex = "";
        if(viewTeacherAndAdministrator.man.isSelected()){
            sex=sex+ viewTeacherAndAdministrator.man.getText();
        }else if(viewTeacherAndAdministrator.woman.isSelected()){
            sex=sex+ viewTeacherAndAdministrator.woman.getText();
        }
        if(id.length()==0||name.length()==0||age.length()==0||college.length()==0||major.length()==0||teacherTitle.length()==0||
                politics.length()==0||politicsTitle.length()==0||sex.length()==0)        return;
        Table.tableTeacherAndAdministrator tableTeacherAndAdministrator = new Table.tableTeacherAndAdministrator();
        Insert.insertTeacherAndAdministrator insertTeacherAndAdministrator= new Insert.insertTeacherAndAdministrator();
        tableTeacherAndAdministrator.setId(id);
        tableTeacherAndAdministrator.setName(name);
        tableTeacherAndAdministrator.setSex(sex);
        tableTeacherAndAdministrator.setAge(age);
        tableTeacherAndAdministrator.setCollege(college);
        tableTeacherAndAdministrator.setMajor(major);
        tableTeacherAndAdministrator.setTeacherTitle(teacherTitle);
        tableTeacherAndAdministrator.setPolitics(politics);
        tableTeacherAndAdministrator.setPoliticsTitle(politicsTitle);
        int isOK=insertTeacherAndAdministrator.insert(tableTeacherAndAdministrator);
        if(isOK!=0){
            JOptionPane.showMessageDialog(new View.Teacherview.viewTeacherAndAdministrator(),"添加成功！","提示",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(new View.Teacherview.viewTeacherAndAdministrator(),"添加失败，该教师兼行政人员可能已存在！","提示",JOptionPane.WARNING_MESSAGE);
        }
        viewTeacherAndAdministrator.id.setText("");
        viewTeacherAndAdministrator.name.setText("");
        viewTeacherAndAdministrator.age.setText("");
        viewTeacherAndAdministrator.college.setText("");
        viewTeacherAndAdministrator.major.setText("");
        viewTeacherAndAdministrator.teacherTitle.setText("");
        viewTeacherAndAdministrator.politics.setText("");
        viewTeacherAndAdministrator.politicsTitle.setText("");
    }
    public void setView(View.Teacherview.viewTeacherAndAdministrator view){
        this.viewTeacherAndAdministrator =view;
    }
}
