package keshe2.controlCount;

import keshe2.Countsql;
import keshe2.CountView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControlCountTeacher implements ActionListener {
    ResultSet rs;
    Countsql count=new Countsql();
    int number=0;
    @Override
    public void actionPerformed(ActionEvent e) {
        rs=count.countTeacher();
        try {
            while(rs.next()){
                number++;
            }
        } catch (SQLException ex) {
                ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(new CountView(),"教师共有"+number+"人！","提示",JOptionPane.INFORMATION_MESSAGE);
        number=0;
    }
}
