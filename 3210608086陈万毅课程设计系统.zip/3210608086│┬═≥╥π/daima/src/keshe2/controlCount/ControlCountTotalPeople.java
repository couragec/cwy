package keshe2.controlCount;

import keshe2.Countsql;
import keshe2.CountView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
//总计
public class ControlCountTotalPeople implements ActionListener {
    ResultSet rs1,rs2,rs3,rs4;
    Countsql count=new Countsql();
    int number=0;
    @Override
    public void actionPerformed(ActionEvent e) {
        rs1=count.countTeacher();
        rs2=count.countTester();
        rs3=count.countAdministrator();
        rs4=count.countTeacherAndAdministrator();
        try {
            while(rs1.next()){
                number++;
            }
            while (rs2.next()){
                number++;
            }
            while (rs3.next()){
                number++;
            }
            while(rs4.next()){
                number++;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(new CountView(),"四类人员共有"+number+"人！","提示",JOptionPane.INFORMATION_MESSAGE);
        number=0;
    }
}
