package keshe2.controlCount;

import keshe2.Countsql;
import keshe2.CountView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControlCountTAA implements ActionListener {
    ResultSet rs;
    Countsql count=new Countsql();
    int number;
    @Override
    public void actionPerformed(ActionEvent e) {
        rs=count.countTeacherAndAdministrator();
        try {
            while(rs.next()){
                number++;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        JOptionPane.showMessageDialog(new CountView(),"教师兼行政人员共有"+number+"人！","提示",JOptionPane.INFORMATION_MESSAGE);
        number=0;
    }
}
