package keshe2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControlCountSex implements ActionListener {
    CountView countView;
    ResultSet rs1,rs2,rs3,rs4;
    Countsql count=new Countsql();
    int number=0;
    @Override
    public void actionPerformed(ActionEvent e) {
        rs1=count.countTeacher();
        rs2=count.countTester();
        rs3=count.countAdministrator();
        rs4=count.countTeacherAndAdministrator();
        if(countView.man.isSelected()){
            try {
                while (rs1.next()){
                    if(rs1.getString(3).equals("男")){
                        number++;
                    }
                }
                while (rs2.next()){
                    if(rs2.getString(3).equals("男")){
                        number++;
                    }
                }
                while (rs3.next()){
                    if(rs3.getString(3).equals("男")){
                        number++;
                    }
                }
                while (rs4.next()){
                    if(rs4.getString(3).equals("男")){
                        number++;
                    }
                }
            } catch (SQLException ex) {
                    ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(new CountView(),"四类人员中男性共有"+number+"人！","提示",JOptionPane.INFORMATION_MESSAGE);
            number=0;
        } else if(countView.woman.isSelected()){
            try {
                while (rs1.next()){
                    if(rs1.getString(3).equals("女")){
                        number++;
                    }
                }
                while (rs2.next()){
                    if(rs2.getString(3).equals("女")){
                        number++;
                    }
                }
                while (rs3.next()){
                    if(rs3.getString(3).equals("女")){
                        number++;
                    }
                }
                while (rs4.next()){
                    if(rs4.getString(3).equals("女")){
                        number++;
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(new CountView(),"四类人员中女性共有"+number+"人！","提示",JOptionPane.INFORMATION_MESSAGE);
            number=0;
        }else{
            JOptionPane.showMessageDialog(new CountView(),"请先选择性别！！！","警告",JOptionPane.WARNING_MESSAGE);
        }
    }

    public void setView(CountView countView){
        this.countView=countView;
    }
}
