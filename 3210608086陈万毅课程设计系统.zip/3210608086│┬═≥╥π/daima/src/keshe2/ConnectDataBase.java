package keshe2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectDataBase {
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  //加载驱动
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static Connection getConnection() throws SQLException {
        String url="jdbc:mysql://localhost:3306/keshe";  //连接数据库keshe  登录
        String user="root";
        String password="123456";
        return DriverManager.getConnection(url,user,password);
    }
}
