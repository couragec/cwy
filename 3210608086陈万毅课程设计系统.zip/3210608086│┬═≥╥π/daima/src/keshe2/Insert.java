package keshe2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Insert {
    //行政人员
    public static class insertAdministrator {
        int isOK;
        public int insert(Table.tableAdministrator tableAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                String sql="insert into administrator values(?,?,?,?,?,?);";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1, tableAdministrator.getId());
                ps.setString(2, tableAdministrator.getName());
                ps.setString(3, tableAdministrator.getSex());
                ps.setString(4, tableAdministrator.getAge());
                ps.setString(5, tableAdministrator.getPolitics());
                ps.setString(6, tableAdministrator.getTitle());
                isOK=ps.executeUpdate();
                con.close();
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }
    //老师
    public static class insertTeacher {
        int isOK;
        public int insert(Table.tableTeacher tableTeacher){
            try {
                Connection con=ConnectDataBase.getConnection();
                String sql="insert into teacher values(?,?,?,?,?,?,?);";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1, tableTeacher.getId());
                ps.setString(2, tableTeacher.getName());
                ps.setString(3, tableTeacher.getSex());
                ps.setString(4, tableTeacher.getAge());
                ps.setString(5, tableTeacher.getCollege());
                ps.setString(6, tableTeacher.getMajor());
                ps.setString(7, tableTeacher.getTitle());
                isOK=ps.executeUpdate();
                con.close();
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }

    }
    //兼有
    public static class insertTeacherAndAdministrator {
        int isOK;
        public int insert(Table.tableTeacherAndAdministrator tableTeacherAndAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                String sql="insert into teacherandadministrator values(?,?,?,?,?,?,?,?,?);";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1, tableTeacherAndAdministrator.getId());
                ps.setString(2, tableTeacherAndAdministrator.getName());
                ps.setString(3, tableTeacherAndAdministrator.getSex());
                ps.setString(4, tableTeacherAndAdministrator.getAge());
                ps.setString(5, tableTeacherAndAdministrator.getCollege());
                ps.setString(6, tableTeacherAndAdministrator.getMajor());
                ps.setString(7, tableTeacherAndAdministrator.getTeacherTitle());
                ps.setString(8, tableTeacherAndAdministrator.getPolitics());
                ps.setString(9, tableTeacherAndAdministrator.getPoliticsTitle());
                isOK=ps.executeUpdate();
                con.close();
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }
    //实验员
    public static class insertTester {
        int isOK;
        public int insert(Table.tableTester tableTester){
            try {
                Connection con=ConnectDataBase.getConnection();
                String sql="insert into tester values(?,?,?,?,?,?);";
                PreparedStatement ps=con.prepareStatement(sql);
                ps.setString(1, tableTester.getId());
                ps.setString(2, tableTester.getName());
                ps.setString(3, tableTester.getSex());
                ps.setString(4, tableTester.getAge());
                ps.setString(5, tableTester.getLaboratory());
                ps.setString(6, tableTester.getJob());
                isOK=ps.executeUpdate();
                con.close();
            } catch (SQLException e) {
                isOK=0;
            }
            return isOK;
        }
    }
}
