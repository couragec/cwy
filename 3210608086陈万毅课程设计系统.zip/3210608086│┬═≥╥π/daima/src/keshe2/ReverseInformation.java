package keshe2;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class ReverseInformation {
    int isOK;
    public int reverse(String s){
        try {
            Connection con=ConnectDataBase.getConnection();
            Statement sta=con.createStatement();
            isOK=sta.executeUpdate(s);
            con.close();
        } catch (SQLException e) {
            //isOK=0;
            System.out.println(e);
        }
        return isOK;
    }
}
