package keshe2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlShow implements ActionListener{
    static JFrame jf=new JFrame("3210608086陈万毅显示人员信息");

    JToolBar jToolBar=new JToolBar();
    JButton add=new JButton("-添加信息- ");
    JButton query=new JButton(" -查询信息- ");
    JButton show=new JButton(" -显示信息- ");
    JButton edit=new JButton(" -编辑信息- ");
    JButton delete=new JButton(" -删除信息- ");
    JButton count=new JButton(" -统计信息- ");

    JTabbedPane jtp=new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);
    Show.ShowTeacherView showTeacherView =new Show.ShowTeacherView();
    Show.ShowTesterView showTesterView =new Show.ShowTesterView();
    Show.ShowAdministratorView showAdministratorView =new Show.ShowAdministratorView();
    Show.ShowTeacherAndAdministratorView showTeacherAndAdministratorView =new Show.ShowTeacherAndAdministratorView();
    @Override
    public void actionPerformed(ActionEvent e) {
        init();
        addAction();
        View.jf.setVisible(false);
        ControlCount.jf.setVisible(false);
        ControlDelete.jf.setVisible(false);
        ControlEdit.jf.setVisible(false);
        ControlQuery.jf.setVisible(false);
    }
    public void addAction(){
        query.addActionListener(new ControlQuery());     //查询
        show.addActionListener(new ControlShow());       //显示
        edit.addActionListener(new ControlEdit());       //编辑
        delete.addActionListener(new ControlDelete());   //删除
        count.addActionListener(new ControlCount());     //统计
    }
    public void init(){
        jToolBar.add(add);
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar, BorderLayout.NORTH);

        jtp.addTab("教师", showTeacherView);
        jtp.addTab("实验员", showTesterView);
        jtp.addTab("行政人员", showAdministratorView);
        jtp.addTab("教师兼行政人员", showTeacherAndAdministratorView);
        jf.setLocation(600,400);
        jf.add(jtp);
        jf.pack();
        jf.setVisible(true);
    }
}
