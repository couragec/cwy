package keshe2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Select {
    public static class selectAdministrator {
        ResultSet rs;
        public ResultSet queryID(Table.tableAdministrator tableAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from administrator where 编号 = '"+ tableAdministrator.getId()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }

        public ResultSet queryName(Table.tableAdministrator tableAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from administrator where 姓名 = '"+ tableAdministrator.getName()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }
    }
    //教师
    public static class selectTeacher {
        ResultSet rs;
        public ResultSet queryID(Table.tableTeacher tableTeacher){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from teacher where id = '"+ tableTeacher.getId()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;

            }
            return rs;
        }

        public ResultSet queryName(Table.tableTeacher tableTeacher){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from teacher where name = '"+ tableTeacher.getName()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }
    }
    //兼有
    public static class selectTeacherAndAdministrator {
        ResultSet rs;
        public ResultSet queryID(Table.tableTeacherAndAdministrator tableTeacherAndAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from teacherandadministrator where 编号 = '"+ tableTeacherAndAdministrator.getId()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }

        public ResultSet queryName(Table.tableTeacherAndAdministrator tableTeacherAndAdministrator){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from teacherandadministrator where 姓名 = '"+ tableTeacherAndAdministrator.getName()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }
    }

    public static class selectTester {
        ResultSet rs;
        public ResultSet queryID(Table.tableTester tableTester){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from tester where 编号 = '"+ tableTester.getId()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }

        public ResultSet queryName(Table.tableTester tableTester){
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from tester where 姓名 = '"+ tableTester.getName()+"';";
                rs=sta.executeQuery(sql);
            } catch (SQLException e) {
                rs=null;
            }
            return rs;
        }
    }
}
