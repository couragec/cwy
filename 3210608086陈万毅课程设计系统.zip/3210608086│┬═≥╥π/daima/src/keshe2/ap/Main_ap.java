package keshe2.ap;

import keshe2.View;

public class Main_ap {
    public static void main(String[] args) {
        View ap = new View();
    }
}
