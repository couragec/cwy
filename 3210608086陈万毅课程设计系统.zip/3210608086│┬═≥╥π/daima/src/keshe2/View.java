package keshe2;

import javax.swing.*;
import java.awt.*;

public class View {
    public static JFrame jf=new JFrame("陈万毅3210608086高校人员信息管理系统");

    //上方功能框
    JToolBar jToolBar=new JToolBar();
    JButton query=new JButton(" -查询信息- ");
    JButton show=new JButton(" -显示信息- ");
    JButton edit=new JButton(" -编辑信息- ");
    JButton delete=new JButton(" -删除信息- ");
    JButton count=new JButton(" -统计信息- ");
    JTabbedPane jtp=new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);

    public View() {
        init();
        addAction();
    }

    public void init(){
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar,BorderLayout.NORTH);

        jtp.addTab("教师",new Teacherview());
        jtp.addTab("实验员",new Teacherview.viewTeacherAndAdministrator.viewTester());
        jtp.addTab("行政人员",new viewAdministrator());
        jtp.addTab("教师兼行政人员",new Teacherview.viewTeacherAndAdministrator());

        jf.add(jtp);
        jf.pack();
        jf.setLocation(600,400);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

   public void addAction() {
       query.addActionListener(new ControlQuery());     //查询
       show.addActionListener(new ControlShow());       //显示
       edit.addActionListener(new ControlEdit());       //编辑
       delete.addActionListener(new ControlDelete());   //删除
       count.addActionListener(new ControlCount());     //统计
   }
    //行政人员
    public static class viewAdministrator extends JPanel {
        JLabel ID=new JLabel("编号");
        public JTextField id=new JTextField(11);
        JLabel Name=new JLabel("姓名");
        public JTextField name=new JTextField(11);
        JLabel Sex=new JLabel("性别");
        ButtonGroup bg=new ButtonGroup();
        public JRadioButton man=new JRadioButton("男");
        public JRadioButton woman=new JRadioButton("女");
        JLabel Age=new JLabel("年龄");
        public JTextField age=new JTextField(11);
        JLabel Politics=new JLabel("政治面貌");
        public JTextField politics=new JTextField(11);
        JLabel Title=new JLabel("职称");
        public JTextField title=new JTextField(11);
        JButton add=new JButton("我要添加");
        ControlA controlA;
        public viewAdministrator(){
            init();
            addAction();
        }
        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(ID);
            h1.add(id);
            h1.add(Name);
            h1.add(name);
            Box h2=Box.createHorizontalBox();
            h2.add(Age);
            h2.add(age);
            h2.add(Politics);
            h2.add(politics);
            Box h3=Box.createHorizontalBox();
            h3.add(Title);
            h3.add(title);
            bg.add(man);
            bg.add(woman);
            h3.add(Sex);
            h3.add(man);
            h3.add(woman);
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(Box.createVerticalStrut(10));
            v.add(h2);
            v.add(Box.createVerticalStrut(10));
            v.add(h3);
            v.add(Box.createVerticalStrut(10));
            v.add(add);
            v.add(Box.createVerticalStrut(10));
            add(v);
        }
        public void addAction(){
            controlA =new ControlA();
            controlA.setView(this);
            add.addActionListener(controlA);
        }
    }
    //老师
    public static class Teacherview extends JPanel {
        JLabel ID=new JLabel("编号");
        JTextField id=new JTextField(15);
        JLabel Name=new JLabel("姓名");
        JTextField name=new JTextField(15);
        JLabel Sex=new JLabel("性别");
        ButtonGroup bg=new ButtonGroup();
        JRadioButton man=new JRadioButton("男");
        JRadioButton woman=new JRadioButton("女");
        JLabel Age=new JLabel("年龄");
        JTextField age=new JTextField(15);
        JLabel College=new JLabel("系部");
        JTextField college=new JTextField(15);
        JLabel Major=new JLabel("专业");
        JTextField major=new JTextField(15);
        JLabel Title=new JLabel("职称");
        JTextField title=new JTextField(15);
        JButton add=new JButton("我要添加");
        HandleTeacher handleTeacher;

        public Teacherview() {
            init();
            addAction();
        }

        public void init(){
            Box h1=Box.createHorizontalBox();
            h1.add(ID);
            h1.add(id);
            h1.add(Name);
            h1.add(name);
            Box h2=Box.createHorizontalBox();
            h2.add(Age);
            h2.add(age);
            h2.add(College);
            h2.add(college);
            Box h3=Box.createHorizontalBox();
            h3.add(Major);
            h3.add(major);
            h3.add(Title);
            h3.add(title);
            Box h4=Box.createHorizontalBox();
            bg.add(man);
            bg.add(woman);
            h4.add(Sex);
            h4.add(man);
            h4.add(woman);
            h4.add(add);
            //组装竖直视图
            Box v=Box.createVerticalBox();
            v.add(h1);
            v.add(Box.createVerticalStrut(10));
            v.add(h2);
            v.add(Box.createVerticalStrut(10));
            v.add(h3);
            v.add(Box.createVerticalStrut(10));
            v.add(h4);
            v.add(Box.createVerticalStrut(10));
            add(v);
        }
        public void addAction(){
            handleTeacher=new HandleTeacher();
            handleTeacher.setView(this);
            add.addActionListener(handleTeacher);
        }
        //教师兼行政人员
        public static class viewTeacherAndAdministrator extends JPanel {
            JLabel ID=new JLabel("编号");
            JTextField id=new JTextField(11);
            JLabel Name=new JLabel("姓名");
            JTextField name=new JTextField(11);
            JLabel Sex=new JLabel("性别");
            ButtonGroup bg=new ButtonGroup();
            JRadioButton man=new JRadioButton("男");
            JRadioButton woman=new JRadioButton("女");
            JLabel Age=new JLabel("年龄");
            JTextField age=new JTextField(11);
            JLabel College=new JLabel("学院");
            JTextField college=new JTextField(11);
            JLabel Major=new JLabel("专业");
            JTextField major=new JTextField(11);
            JLabel TeacherTitle=new JLabel("教师职称");
            JTextField teacherTitle=new JTextField(11);
            JLabel Politics=new JLabel("政治面貌");
            JTextField politics=new JTextField(11);
            JLabel PoliticsTitle=new JLabel("政治职称");
            JTextField politicsTitle=new JTextField(11);
            JButton add=new JButton("我要添加");
            HandleTeacherAndAdministrator handleTeacherAndAdministrator;

            public viewTeacherAndAdministrator(){
                init();
                addAction();
            }

            public void init(){
                Box h1=Box.createHorizontalBox();
                h1.add(ID);
                h1.add(id);
                Box h2=Box.createHorizontalBox();
                h2.add(Name);
                h2.add(name);
                Box h3=Box.createHorizontalBox();
                bg.add(man);
                bg.add(woman);
                h3.add(Sex);
                h3.add(man);
                h3.add(woman);
                Box h4=Box.createHorizontalBox();
                h4.add(Age);
                h4.add(age);
                Box h5=Box.createHorizontalBox();
                h5.add(College);
                h5.add(college);
                Box h6=Box.createHorizontalBox();
                h6.add(Major);
                h6.add(major);
                Box h7=Box.createHorizontalBox();
                h7.add(TeacherTitle);
                h7.add(teacherTitle);
                Box h8=Box.createHorizontalBox();
                h8.add(Politics);
                h8.add(politics);
                Box h9=Box.createHorizontalBox();
                h9.add(PoliticsTitle);
                h9.add(politicsTitle);
                Box v=Box.createVerticalBox();
                v.add(h1);
                v.add(h2);
                v.add(h3);
                v.add(h4);
                v.add(h5);
                v.add(h6);
                v.add(h7);
                v.add(h8);
                v.add(h9);
                v.add(add);
                add(v);
            }

            public void addAction(){
                handleTeacherAndAdministrator=new HandleTeacherAndAdministrator();
                handleTeacherAndAdministrator.setView(this);
                add.addActionListener(handleTeacherAndAdministrator);
            }
            //实验员
            public static class viewTester extends JPanel {
                JLabel ID=new JLabel("编号");
                JTextField id=new JTextField(11);
                JLabel Name=new JLabel("姓名");
                JTextField name=new JTextField(11);
                JLabel Sex=new JLabel("性别");
                ButtonGroup bg=new ButtonGroup();
                JRadioButton man=new JRadioButton("男");
                JRadioButton woman=new JRadioButton("女");
                JLabel Age=new JLabel("年龄");
                JTextField age=new JTextField(11);
                JLabel Laboratory=new JLabel("实验室");
                JTextField laboratory=new JTextField(11);
                JLabel Job=new JLabel("职务");
                JTextField job=new JTextField(11);
                JButton add=new JButton("我要添加");
                HandleTester handleTester;

                public viewTester(){
                    init();
                    addAction();
                }
                public void init(){
                    Box h1=Box.createHorizontalBox();
                    h1.add(ID);
                    h1.add(id);
                    h1.add(Name);
                    h1.add(name);
                    Box h2=Box.createHorizontalBox();
                    h2.add(Age);
                    h2.add(age);
                    h2.add(Laboratory);
                    h2.add(laboratory);
                    Box h3=Box.createHorizontalBox();
                    h3.add(Job);
                    h3.add(job);
                    Box h4=Box.createHorizontalBox();
                    bg.add(man);
                    bg.add(woman);
                    h4.add(Sex);
                    h4.add(man);
                    h4.add(woman);
                    h4.add(add);
                    Box v=Box.createVerticalBox();
                    v.add(h1);
                    v.add(Box.createVerticalStrut(10));
                    v.add(h2);
                    v.add(Box.createVerticalStrut(10));
                    v.add(h3);
                    v.add(Box.createVerticalStrut(10));
                    v.add(h4);
                    v.add(Box.createVerticalStrut(10));
                    add(v);
                }
                public void addAction(){
                    handleTester=new HandleTester();
                    handleTester.setView(this);
                    add.addActionListener(handleTester);
                }
            }
        }
    }
}
