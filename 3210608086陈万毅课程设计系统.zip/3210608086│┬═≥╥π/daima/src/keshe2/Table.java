package keshe2;

import javax.swing.*;
import javax.swing.table.TableCellRenderer;
import java.awt.*;

public class Table {
    public static class tableAdministrator {
        String id;
        String name;
        String sex;
        String age;
        String politics;
        String title;

        public void setId(String id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public void setPolitics(String politics) {
            this.politics = politics;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getSex() {
            return sex;
        }

        public String getAge() {
            return age;
        }

        public String getPolitics() {
            return politics;
        }

        public String getTitle() {
            return title;
        }
    }

    public static class TableCellTextAreaRenderer extends JTextArea implements TableCellRenderer {

        public TableCellTextAreaRenderer(){
            setLineWrap(true);
            setWrapStyleWord(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            int maxPreferredHeight=30;
            for(int i=0;i<table.getColumnCount();i++){
                setText(""+table.getValueAt(row,i));
                setSize(table.getColumnModel().getColumn(column).getWidth(),0);
                maxPreferredHeight=Math.max(maxPreferredHeight,getPreferredSize().height);
            }
            if(table.getRowHeight(row)!=maxPreferredHeight){
                table.setRowHeight(row,maxPreferredHeight);
            }
            if(isSelected){
                this.setBackground(table.getSelectionBackground());
            }else{
                this.setBackground(table.getBackground());
            }
            setText(value==null?"":value.toString());
            return this;
        }
    }
    //老师
    public static class tableTeacher {
        String id;
        String name;
        String sex;
        String age;
        String college;
        String major;
        String title;

        public void setId(String id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public void setCollege(String college) {
            this.college = college;
        }

        public void setMajor(String major) {
            this.major = major;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getSex() {
            return sex;
        }

        public String getAge() {
            return age;
        }

        public String getCollege() {
            return college;
        }

        public String getMajor() {
            return major;
        }

        public String getTitle() {
            return title;
        }
    }
    //兼有
    public static class tableTeacherAndAdministrator {
        String id;
        String name;
        String sex;
        String age;
        String college;
        String major;
        String teacherTitle;
        String politics;
        String politicsTitle;

        public void setId(String id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public void setCollege(String college) {
            this.college = college;
        }

        public void setMajor(String major) {
            this.major = major;
        }

        public void setTeacherTitle(String teacherTitle) {
            this.teacherTitle = teacherTitle;
        }

        public void setPolitics(String politics) {
            this.politics = politics;
        }

        public void setPoliticsTitle(String politicsTitle) {
            this.politicsTitle = politicsTitle;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getSex() {
            return sex;
        }

        public String getAge() {
            return age;
        }

        public String getCollege() {
            return college;
        }

        public String getMajor() {
            return major;
        }

        public String getTeacherTitle() {
            return teacherTitle;
        }

        public String getPolitics() {
            return politics;
        }

        public String getPoliticsTitle() {
            return politicsTitle;
        }
    }

    public static class tableTester {
        String id;
        String name;
        String sex;
        String age;
        String laboratory;
        String job;

        public void setId(String id) {
            this.id = id;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void setSex(String sex) {
            this.sex = sex;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public void setLaboratory(String laboratory) {
            this.laboratory = laboratory;
        }

        public void setJob(String job) {
            this.job = job;
        }

        public String getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getSex() {
            return sex;
        }

        public String getAge() {
            return age;
        }

        public String getLaboratory() {
            return laboratory;
        }

        public String getJob() {
            return job;
        }
    }
}
