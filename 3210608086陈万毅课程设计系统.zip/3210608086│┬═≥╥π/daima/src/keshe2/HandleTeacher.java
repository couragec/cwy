package keshe2;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//教师监视器
public class HandleTeacher implements ActionListener {

    View.Teacherview viewTeacher;
    @Override
    public void actionPerformed(ActionEvent e) {
        //获取信息
        String id= viewTeacher.id.getText();
        String name= viewTeacher.name.getText();
        String age= viewTeacher.age.getText();
        String college= viewTeacher.college.getText();
        String major= viewTeacher.major.getText();
        String title= viewTeacher.title.getText();
        String sex = "";
        //后续统计男女
        if(viewTeacher.man.isSelected()){
            sex=sex+ viewTeacher.man.getText();
        }else if(viewTeacher.woman.isSelected()){
            sex=sex+ viewTeacher.woman.getText();
        }
        if(id.length()==0||name.length()==0||age.length()==0||college.length()==0||major.length()==0||
            title.length()==0||sex.length()==0)        return;
        Table.tableTeacher tableTeacher =new Table.tableTeacher();
        Insert.insertTeacher insertTeacher=new Insert.insertTeacher();
        tableTeacher.setId(id);
        tableTeacher.setName(name);
        tableTeacher.setSex(sex);
        tableTeacher.setAge(age);
        tableTeacher.setCollege(college);
        tableTeacher.setMajor(major);
        tableTeacher.setTitle(title);
        int isOK=insertTeacher.insert(tableTeacher);
        if(isOK!=0){
            JOptionPane.showMessageDialog(new View.Teacherview(),"添加成功！","提示",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(new View.Teacherview(),"添加失败，该老师可能已存在！","提示",JOptionPane.WARNING_MESSAGE);
        }
        viewTeacher.id.setText("");
        viewTeacher.name.setText("");
        viewTeacher.age.setText("");
        viewTeacher.college.setText("");
        viewTeacher.major.setText("");
        viewTeacher.title.setText("");
    }
    public void setView(View.Teacherview view){
        this.viewTeacher =view;
    }
}
