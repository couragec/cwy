package keshe2;

import keshe2.controlCount.*;

import javax.swing.*;
import java.awt.*;

public class CountView extends JPanel {


    JLabel teacher=new JLabel("教师数量");
    JButton b1=new JButton("查看");
    JLabel tester=new JLabel("实验员数量");
    JButton b2=new JButton("查看");
    JLabel administrator=new JLabel("行政人员数量");
    JButton b3=new JButton("查看");
    JLabel teacherAndAdministrator=new JLabel("教师兼行政人员数量");
    JButton b4=new JButton("查看");
    JLabel total=new JLabel("总人数");
    JButton b5=new JButton("查看");
    JLabel jLabel=new JLabel("男/女人数,请选择:");
    JRadioButton man=new JRadioButton("男");
    JRadioButton woman=new JRadioButton("女");
    ButtonGroup bg=new ButtonGroup();
    JButton b6=new JButton("查看");
    ControlCountSex controlCountSex;

    public CountView(){
        init();
        addAction();
    }

    public void init(){
        setLayout(new GridLayout(3,2));
        Box v1=Box.createVerticalBox();
        v1.add(teacher);
        v1.add(b1);
        Box v2=Box.createVerticalBox();
        v2.add(tester);
        v2.add(b2);
        Box v3=Box.createVerticalBox();
        v3.add(administrator);
        v3.add(b3);
        Box v4=Box.createVerticalBox();
        v4.add(teacherAndAdministrator);
        v4.add(b4);
        Box v5=Box.createVerticalBox();
      //  Box h=Box.createHorizontalBox();
        bg.add(man);
        bg.add(woman);
        v5.add(jLabel);
        v5.add(man);
        v5.add(woman);
        v5.add(b6);
        Box v6=Box.createVerticalBox();
        v6.add(total);
        v6.add(b5);
        add(v1);
        add(v2);
        add(v3);
        add(v4);
        add(v5);
        add(v6);
    }

    public void addAction(){
        b1.addActionListener(new ControlCountTeacher());
        b2.addActionListener(new ControlCountTester());
        b3.addActionListener(new ControlCountAdministrator());
        b4.addActionListener(new ControlCountTAA());
        b5.addActionListener(new ControlCountTotalPeople());
        controlCountSex =new ControlCountSex();
        controlCountSex.setView(this);
        b6.addActionListener(controlCountSex);
    }
}
