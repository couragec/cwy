package keshe2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlDelete implements ActionListener {
    static JFrame jf=new JFrame("3210608086陈万毅删除人员信息");

    JToolBar jToolBar=new JToolBar();
    JButton add=new JButton("-添加信息- ");
    JButton query=new JButton(" -查询信息- ");
    JButton show=new JButton(" -显示信息- ");
    JButton edit=new JButton(" -编辑信息- ");
    JButton delete=new JButton(" -删除信息- ");
    JButton count=new JButton(" -统计信息- ");

    JTabbedPane jtp=new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);
    Delete.deleteTeacherView deleteTeacherView=new Delete.deleteTeacherView();
    Delete.deleteTesterView deleteTesterView=new Delete.deleteTesterView();
    Delete.deleteAdministratorView deleteAdministratorView=new Delete.deleteAdministratorView();
    Delete.deleteTeacherAndAdministratorView deleteTeacherAndAdministratorView=new Delete.deleteTeacherAndAdministratorView();

    @Override
    public void actionPerformed(ActionEvent e) {
        init();
        addAction();
        View.jf.setVisible(false);
        ControlCount.jf.setVisible(false);
        ControlEdit.jf.setVisible(false);
        ControlShow.jf.setVisible(false);
        ControlQuery.jf.setVisible(false);
    }
    public void addAction(){
        query.addActionListener(new ControlQuery());     //查询
        show.addActionListener(new ControlShow());       //显示
        edit.addActionListener(new ControlEdit());       //编辑
        delete.addActionListener(new ControlDelete());   //删除
        count.addActionListener(new ControlCount());     //统计
    }

    public void init(){
        jToolBar.add(add);
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar, BorderLayout.NORTH);

        jtp.addTab("教师",deleteTeacherView);
        jtp.addTab("实验员",deleteTesterView);
        jtp.addTab("行政人员",deleteAdministratorView);
        jtp.addTab("教师兼行政人员",deleteTeacherAndAdministratorView);
        jf.add(jtp);
        jf.setLocation(600,400);
        jf.pack();
        jf.setVisible(true);
    }

    public static class HandleDeleteAdministratorID implements ActionListener {
        Delete.deleteAdministratorView deleteAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String id=deleteAdministratorView.id.getText();
            if(id.length()==0)  return;
            Table.tableAdministrator tableAdministrator=new Table.tableAdministrator();
            tableAdministrator.setId(id);
            Delete.DeleteAdministrator deleteAdministrator=new Delete.DeleteAdministrator();
            int isOK=deleteAdministrator.deleteID(tableAdministrator);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteAdministratorView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteAdministratorView,"删除失败，该行政人员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteAdministratorView.id.setText("");
        }

        public void setView(Delete.deleteAdministratorView deleteAdministratorView){
            this.deleteAdministratorView=deleteAdministratorView;
        }
    }

    public static class HandleDeleteAdministratorName implements ActionListener {
        Delete.deleteAdministratorView deleteAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String name=deleteAdministratorView.name.getText();
            if(name.length()==0)  return;
            Table.tableAdministrator tableAdministrator=new Table.tableAdministrator();
            tableAdministrator.setName(name);
            Delete.DeleteAdministrator deleteAdministrator=new Delete.DeleteAdministrator();
            int isOK=deleteAdministrator.deleteName(tableAdministrator);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteAdministratorView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteAdministratorView,"删除失败，该行政人员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteAdministratorView.name.setText("");
        }

        public void setView(Delete.deleteAdministratorView deleteAdministratorView){
            this.deleteAdministratorView=deleteAdministratorView;
        }
    }

    public static class HandleDeleteTeacherAndAdministratorID implements ActionListener {
        Delete.deleteTeacherAndAdministratorView deleteTeacherAndAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String id=deleteTeacherAndAdministratorView.id.getText();
            if(id.length()==0)  return;
            Table.tableTeacherAndAdministrator tableTeacherAndAdministrator=new Table.tableTeacherAndAdministrator();
            tableTeacherAndAdministrator.setId(id);
            Delete.DeleteTeacherAndAdministrator deleteTeacherAndAdministrator=new Delete.DeleteTeacherAndAdministrator();
            int isOK=deleteTeacherAndAdministrator.deleteID(tableTeacherAndAdministrator);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTeacherAndAdministratorView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTeacherAndAdministratorView,"删除失败，该教师兼行政人员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTeacherAndAdministratorView.id.setText("");
        }

        public void setView(Delete.deleteTeacherAndAdministratorView deleteTeacherAndAdministratorView){
            this.deleteTeacherAndAdministratorView=deleteTeacherAndAdministratorView;
        }
    }

    public static class HandleDeleteTeacherAndAdministratorName implements ActionListener {
        Delete.deleteTeacherAndAdministratorView deleteTeacherAndAdministratorView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String name=deleteTeacherAndAdministratorView.name.getText();
            if(name.length()==0)  return;
            Table.tableTeacherAndAdministrator tableTeacherAndAdministrator=new Table.tableTeacherAndAdministrator();
            tableTeacherAndAdministrator.setName(name);
            Delete.DeleteTeacherAndAdministrator deleteTeacherAndAdministrator=new Delete.DeleteTeacherAndAdministrator();
            int isOK=deleteTeacherAndAdministrator.deleteName(tableTeacherAndAdministrator);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTeacherAndAdministratorView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTeacherAndAdministratorView,"删除失败，该教师兼行政人员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTeacherAndAdministratorView.name.setText("");
        }

        public void setView(Delete.deleteTeacherAndAdministratorView deleteTeacherAndAdministratorView){
            this.deleteTeacherAndAdministratorView=deleteTeacherAndAdministratorView;
        }
    }

    public static class HandleDeleteTeacherID implements ActionListener {
        Delete.deleteTeacherView deleteTeacherView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String id=deleteTeacherView.id.getText();
            if(id.length()==0)  return;
            Table.tableTeacher tableTeacher=new Table.tableTeacher();
            tableTeacher.setId(id);
            Delete.DeleteTeacher deleteTeacher=new Delete.DeleteTeacher();
            int isOK=deleteTeacher.deleteID(tableTeacher);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTeacherView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTeacherView,"删除失败，该教师不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTeacherView.id.setText("");
        }

        public void setView(Delete.deleteTeacherView deleteTeacherView){
            this.deleteTeacherView=deleteTeacherView;
        }
    }

    public static class HandleDeleteTeacherName implements ActionListener {
        Delete.deleteTeacherView deleteTeacherView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String name=deleteTeacherView.name.getText();
            if(name.length()==0)  return;
            Table.tableTeacher tableTeacher=new Table.tableTeacher();
            tableTeacher.setName(name);
            Delete.DeleteTeacher deleteTeacher=new Delete.DeleteTeacher();
            int isOK=deleteTeacher.deleteName(tableTeacher);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTeacherView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTeacherView,"删除失败，该教师不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTeacherView.name.setText("");
        }

        public void setView(Delete.deleteTeacherView deleteTeacherView){
            this.deleteTeacherView=deleteTeacherView;
        }
    }

    public static class HandleDeleteTesterID implements ActionListener {
        Delete.deleteTesterView deleteTesterView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String id=deleteTesterView.id.getText();
            if(id.length()==0)    return;
            Table.tableTester tableTester=new Table.tableTester();
            Delete.DeleteTester deleteTester=new Delete.DeleteTester();
            tableTester.setId(id);
            int isOK=deleteTester.deleteID(tableTester);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTesterView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTesterView,"删除失败，该实验员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTesterView.id.setText("");
        }

        public void setView(Delete.deleteTesterView deleteTesterView){
            this.deleteTesterView=deleteTesterView;
        }
    }

    public static class HandleDeleteTesterName implements ActionListener {
        Delete.deleteTesterView deleteTesterView;

        @Override
        public void actionPerformed(ActionEvent e) {
            String name=deleteTesterView.name.getText();
            if(name.length()==0)    return;
            Table.tableTester tableTester=new Table.tableTester();
            Delete.DeleteTester deleteTester=new Delete.DeleteTester();
            tableTester.setName(name);
            int isOK=deleteTester.deleteName(tableTester);
            if(isOK!=0){
                JOptionPane.showMessageDialog(deleteTesterView,"删除成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(deleteTesterView,"删除失败，该实验员不存在！","警告",JOptionPane.WARNING_MESSAGE);
            }
            deleteTesterView.name.setText("");
        }

        public void setView(Delete.deleteTesterView deleteTesterView){
            this.deleteTesterView=deleteTesterView;
        }
    }
}
