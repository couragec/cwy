package keshe2;

import keshe2.Insert;
import keshe2.Table;
import keshe2.View;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlA implements ActionListener {
    View.viewAdministrator viewAdministrator;

    @Override
    public void actionPerformed(ActionEvent e) {
        String id= viewAdministrator.id.getText();
        String name= viewAdministrator.name.getText();
        String age= viewAdministrator.age.getText();
        String politics= viewAdministrator.politics.getText();
        String title= viewAdministrator.title.getText();
        String sex = "";
        if(viewAdministrator.man.isSelected()){
            sex=sex+ viewAdministrator.man.getText();
        }else if(viewAdministrator.woman.isSelected()){
            sex=sex+ viewAdministrator.woman.getText();
        }

        if(id.length()==0||name.length()==0||age.length()==0||politics.length()==0||title.length()==0|| sex.length()==0)
            return;
        Table.tableAdministrator tableAdministrator = new Table.tableAdministrator();
        Insert.insertAdministrator insertAdministrator= new Insert.insertAdministrator();
        tableAdministrator.setId(id);
        tableAdministrator.setName(name);
        tableAdministrator.setSex(sex);
        tableAdministrator.setAge(age);
        tableAdministrator.setPolitics(politics);
        tableAdministrator.setTitle(title);
        int isOK=insertAdministrator.insert(tableAdministrator);
        if(isOK!=0){
            JOptionPane.showMessageDialog(new View.viewAdministrator(),"添加成功！","提示",JOptionPane.INFORMATION_MESSAGE);
        }else{
            JOptionPane.showMessageDialog(new View.viewAdministrator(),"添加失败，该行政人员可能已存在！","提示",JOptionPane.WARNING_MESSAGE);
        }
        viewAdministrator.id.setText("");
        viewAdministrator.name.setText("");
        viewAdministrator.age.setText("");
        viewAdministrator.politics.setText("");
        viewAdministrator.title.setText("");
    }
    public void setView(View.viewAdministrator view){
        this.viewAdministrator =view;
    }
}
