package keshe2.edit;

import keshe2.ControlEdit;

import javax.swing.*;

public class editTAAView extends JPanel {
    JLabel inf=new JLabel("信息包含编号，姓名，性别，年龄，学院");
    JLabel info=new JLabel("专业，教师职称，政治面貌，政治职称");
    JLabel jLabel=new JLabel("sql修改：teacherandadministrator");
    public JTextField t=new JTextField(11);
    JButton reverse=new JButton("点击修改");
    ControlEdit.HandleEditTeacherAndAdministrator handleEditTeacherAndAdministrator;

    public editTAAView(){
        init();
        addAction();
    }

    public void init(){
        Box v=Box.createVerticalBox();
        v.add(inf);
        v.add(info);
        v.add(jLabel);
        v.add(t);
        v.add(reverse);
        add(v);
    }

    public void addAction(){
        handleEditTeacherAndAdministrator=new ControlEdit.HandleEditTeacherAndAdministrator();
        handleEditTeacherAndAdministrator.setView(this);
        reverse.addActionListener(handleEditTeacherAndAdministrator);
    }
}
