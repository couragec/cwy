package keshe2.edit;

import keshe2.ControlEdit;

import javax.swing.*;

public class editAdView extends JPanel {
    JLabel inf=new JLabel("id,name,sex,age,status,title");
    JLabel jLabel=new JLabel("sql修改：administrator");
    public JTextField t=new JTextField(11);
    JButton reverse=new JButton("点击修改");
    ControlEdit.HandleEditAdministrator handleEditAdministrator;

    public editAdView(){
        init();
        addAction();
    }

    public void init(){
        Box v=Box.createVerticalBox();
        v.add(inf);
        v.add(jLabel);
        v.add(t);
        v.add(reverse);
        add(v);
    }

    public void addAction(){
        handleEditAdministrator=new ControlEdit.HandleEditAdministrator();
        handleEditAdministrator.setView(this);
        reverse.addActionListener(handleEditAdministrator);
    }
}
