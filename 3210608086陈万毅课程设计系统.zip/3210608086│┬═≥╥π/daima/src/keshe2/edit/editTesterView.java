package keshe2.edit;

import keshe2.ControlEdit;

import javax.swing.*;

public class editTesterView extends JPanel {
    JLabel inf=new JLabel("id,name,sex,age,lab,title");
    JLabel jLabel=new JLabel("sql修改：tester");
    public JTextField t=new JTextField(11);
    JButton reverse=new JButton("点击修改");
    ControlEdit.HandleEditTester handleEditTester;
    public editTesterView(){
        init();
        addAction();
    }

    public void init(){
        Box v=Box.createVerticalBox();
        v.add(inf);
        v.add(jLabel);
        v.add(t);
        v.add(reverse);
        add(v);
    }

    public void addAction(){
        handleEditTester=new ControlEdit.HandleEditTester();
        handleEditTester.setView(this);
        reverse.addActionListener(handleEditTester);
    }
}
