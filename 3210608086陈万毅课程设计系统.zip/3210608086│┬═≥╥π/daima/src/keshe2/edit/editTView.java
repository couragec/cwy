package keshe2.edit;

import keshe2.ControlEdit;

import javax.swing.*;

public class editTView extends JPanel {
    JLabel inf=new JLabel("id,name,sex,age,college,major,title");
    JLabel jLabel=new JLabel("输入sql语句修改:teacher");
    public JTextField t=new JTextField(11);
    JButton reverse=new JButton("点击修改");
    ControlEdit.HandleEditTeacher handleEditTeacher;
    public editTView(){
        init();
        addAction();
    }

    public void init(){
        Box v=Box.createVerticalBox();
        v.add(inf);
        v.add(jLabel);
        v.add(t);
        v.add(reverse);
        add(v);
    }

    public void addAction(){
        handleEditTeacher=new ControlEdit.HandleEditTeacher();
        handleEditTeacher.setView(this);
        reverse.addActionListener(handleEditTeacher);
    }
}
