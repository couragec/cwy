package keshe2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

public class Show {
    //行政人员
    public static class ShowAdministratorView extends JPanel {
        public ShowAdministratorView(){
            Show();
        }

        public void Show(){
            DefaultTableModel model;
            JTable table;
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from administrator;";
                ResultSet rs=sta.executeQuery(sql);
                String[] biaotou={"id","name","sex","age","status","title"};
                Object[][] cellData={};
                model=new DefaultTableModel(cellData,biaotou){
                    public boolean isCellEditable(int rowIndex,int columnIndex){
                        return false;
                    }
                };
                table=new JTable(model);
                String[] data=new String[7];
                while (rs.next()){
                    data[0]=rs.getString(1);
                    data[1]=rs.getString(2);
                    data[2]=rs.getString(3);
                    data[3]=rs.getString(4);
                    data[4]=rs.getString(5);
                    data[5]=rs.getString(6);
                    model.addRow(data);
                }
                rs.close();
                sta.close();
                con.close();
                table.setFillsViewportHeight(true);
                table.setPreferredScrollableViewportSize(new Dimension(600,300));
                JScrollPane scrollPane=new JScrollPane(table);
                table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                table.setDefaultRenderer(Object.class,new Table.TableCellTextAreaRenderer());
                scrollPane.setBounds(0,0,600,300);
                table.setRowHeight(30);
                FitTableColumns(table);
                add(scrollPane);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public static void FitTableColumns(JTable myTable){
            JTableHeader header=myTable.getTableHeader();
            int rowCount=myTable.getRowCount();

            Enumeration columns=myTable.getColumnModel().getColumns();
            while (columns.hasMoreElements()){
                TableColumn column=(TableColumn) columns.nextElement();
                int col=header.getColumnModel().getColumnIndex(column.getIdentifier());
                int width=(int) myTable.getTableHeader().getDefaultRenderer()
                        .getTableCellRendererComponent(myTable,column.getIdentifier(),false,false,-1,col)
                        .getPreferredSize().getWidth();
                for(int row=0;row<rowCount;row++){
                    int preferredWidth=(int)myTable.getCellRenderer(row,col)
                            .getTableCellRendererComponent(myTable,myTable.getValueAt(row,col),false,false,row,col)
                            .getPreferredSize().getWidth();
                    width=Math.max(width,preferredWidth);
                }
                header.setResizingColumn(column);
                column.setWidth(width+myTable.getIntercellSpacing().width+10);
            }
        }
    }
    //兼有
    public static class ShowTeacherAndAdministratorView extends JPanel{
        public ShowTeacherAndAdministratorView(){
            Show();
        }

        public void Show(){
            DefaultTableModel model;
            JTable table;
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from two;";
                ResultSet rs=sta.executeQuery(sql);
                String[] biaotou={"编号","姓名","性别","年龄","学院","专业","教师职称","政治面貌","政治职称"};
                Object[][] cellData={};
                model=new DefaultTableModel(cellData,biaotou){
                    public boolean isCellEditable(int rowIndex,int columnIndex){
                        return false;
                    }
                };
                table=new JTable(model);
                String[] data=new String[9];
                while (rs.next()){
                    data[0]=rs.getString(1);
                    data[1]=rs.getString(2);
                    data[2]=rs.getString(3);
                    data[3]=rs.getString(4);
                    data[4]=rs.getString(5);
                    data[5]=rs.getString(6);
                    data[6]=rs.getString(7);
                    data[7]=rs.getString(8);
                    data[8]=rs.getString(9);
                    model.addRow(data);
                }
                rs.close();
                sta.close();
                con.close();
                table.setFillsViewportHeight(true);
                table.setPreferredScrollableViewportSize(new Dimension(600,300));
                JScrollPane scrollPane=new JScrollPane(table);
                table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                table.setDefaultRenderer(Object.class,new Table.TableCellTextAreaRenderer());
                scrollPane.setBounds(0,0,600,300);
                table.setRowHeight(30);
                FitTableColumns(table);
                add(scrollPane);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public static void FitTableColumns(JTable myTable){
            JTableHeader header=myTable.getTableHeader();
            int rowCount=myTable.getRowCount();

            Enumeration columns=myTable.getColumnModel().getColumns();
            while (columns.hasMoreElements()){
                TableColumn column=(TableColumn) columns.nextElement();
                int col=header.getColumnModel().getColumnIndex(column.getIdentifier());
                int width=(int) myTable.getTableHeader().getDefaultRenderer()
                        .getTableCellRendererComponent(myTable,column.getIdentifier(),false,false,-1,col)
                        .getPreferredSize().getWidth();
                for(int row=0;row<rowCount;row++){
                    int preferredWidth=(int)myTable.getCellRenderer(row,col)
                            .getTableCellRendererComponent(myTable,myTable.getValueAt(row,col),false,false,row,col)
                            .getPreferredSize().getWidth();
                    width=Math.max(width,preferredWidth);
                }
                header.setResizingColumn(column);
                column.setWidth(width+myTable.getIntercellSpacing().width+10);
            }
        }
    }
    //老师
    public static class ShowTeacherView extends JPanel {
        public ShowTeacherView(){
            Show();
        }
        public void Show(){
            DefaultTableModel model;
            JTable table;
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from teacher;";
                ResultSet rs=sta.executeQuery(sql);
                String[] biaotou={"id","name","sex","age","college","major","title"};
                Object[][] cellData={};
                model=new DefaultTableModel(cellData,biaotou){
                    public boolean isCellEditable(int rowIndex,int columnIndex){
                        return false;
                    }
                };
                table=new JTable(model);
                String[] data=new String[7];
                while (rs.next()){
                    data[0]=rs.getString(1);
                    data[1]=rs.getString(2);
                    data[2]=rs.getString(3);
                    data[3]=rs.getString(4);
                    data[4]=rs.getString(5);
                    data[5]=rs.getString(6);
                    data[6]=rs.getString(7);
                    model.addRow(data);
                }
                //关闭IO流
                rs.close();
                sta.close();
                con.close();
                table.setFillsViewportHeight(true);
                table.setPreferredScrollableViewportSize(new Dimension(600,300));
                JScrollPane scrollPane=new JScrollPane(table);
                table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                table.setDefaultRenderer(Object.class,new Table.TableCellTextAreaRenderer());
                scrollPane.setBounds(0,0,600,300);
                table.setRowHeight(30);
                FitTableColumns(table);
                add(scrollPane);

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        public static void FitTableColumns(JTable myTable){
            JTableHeader header=myTable.getTableHeader();
            int rowCount=myTable.getRowCount();

            Enumeration columns=myTable.getColumnModel().getColumns();
            while (columns.hasMoreElements()){
                TableColumn column=(TableColumn) columns.nextElement();
                int col=header.getColumnModel().getColumnIndex(column.getIdentifier());
                int width=(int) myTable.getTableHeader().getDefaultRenderer()
                        .getTableCellRendererComponent(myTable,column.getIdentifier(),false,false,-1,col)
                        .getPreferredSize().getWidth();
                for(int row=0;row<rowCount;row++){
                    int preferredWidth=(int)myTable.getCellRenderer(row,col)
                            .getTableCellRendererComponent(myTable,myTable.getValueAt(row,col),false,false,row,col)
                            .getPreferredSize().getWidth();
                    width=Math.max(width,preferredWidth);
                }
                header.setResizingColumn(column);
                column.setWidth(width+myTable.getIntercellSpacing().width+10);
            }
        }

    }
    //实验员
    public static class ShowTesterView extends JPanel{
        public ShowTesterView(){
            Show();
        }
        public void Show(){
            DefaultTableModel model;
            JTable table;
            try {
                Connection con=ConnectDataBase.getConnection();
                Statement sta=con.createStatement();
                String sql="select * from tester;";
                ResultSet rs=sta.executeQuery(sql);
                String[] biaotou={"id","name","sex","age","lab","title"};
                Object[][] cellData={};
                model=new DefaultTableModel(cellData,biaotou){
                    public boolean isCellEditable(int rowIndex,int columnIndex){
                        return false;
                    }
                };
                table=new JTable(model);
                String[] data=new String[6];
                while (rs.next()){
                    data[0]=rs.getString(1);
                    data[1]=rs.getString(2);
                    data[2]=rs.getString(3);
                    data[3]=rs.getString(4);
                    data[4]=rs.getString(5);
                    data[5]=rs.getString(6);
                    model.addRow(data);
                }
                rs.close();
                sta.close();
                con.close();
                table.setFillsViewportHeight(true);
                table.setPreferredScrollableViewportSize(new Dimension(600,300));
                JScrollPane scrollPane=new JScrollPane(table);
                table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
                table.setDefaultRenderer(Object.class,new Table.TableCellTextAreaRenderer());
                scrollPane.setBounds(0,0,600,300);
                table.setRowHeight(30);
                FitTableColumns(table);
                add(scrollPane);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        public static void FitTableColumns(JTable myTable){
            JTableHeader header=myTable.getTableHeader();
            int rowCount=myTable.getRowCount();

            Enumeration columns=myTable.getColumnModel().getColumns();
            while (columns.hasMoreElements()){
                TableColumn column=(TableColumn) columns.nextElement();
                int col=header.getColumnModel().getColumnIndex(column.getIdentifier());
                int width=(int) myTable.getTableHeader().getDefaultRenderer()
                        .getTableCellRendererComponent(myTable,column.getIdentifier(),false,false,-1,col)
                        .getPreferredSize().getWidth();
                for(int row=0;row<rowCount;row++){
                    int preferredWidth=(int)myTable.getCellRenderer(row,col)
                            .getTableCellRendererComponent(myTable,myTable.getValueAt(row,col),false,false,row,col)
                            .getPreferredSize().getWidth();
                    width=Math.max(width,preferredWidth);
                }
                header.setResizingColumn(column);
                column.setWidth(width+myTable.getIntercellSpacing().width+10);
            }
        }

    }
}
