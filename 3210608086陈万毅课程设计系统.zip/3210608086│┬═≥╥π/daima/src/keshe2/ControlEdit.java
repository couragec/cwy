package keshe2;

import keshe2.edit.editAdView;
import keshe2.edit.editTAAView;
import keshe2.edit.editTView;
import keshe2.edit.editTesterView;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControlEdit implements ActionListener {

    static JFrame jf=new JFrame("3210608086陈万毅编辑人员信息");

    JToolBar jToolBar=new JToolBar();
    JButton add=new JButton("-添加信息- ");
    JButton query=new JButton(" -查询信息- ");
    JButton show=new JButton(" -显示信息- ");
    JButton edit=new JButton(" -编辑信息- ");
    JButton delete=new JButton(" -删除信息- ");
    JButton count=new JButton(" -统计信息- ");

    JTabbedPane jtp=new JTabbedPane(JTabbedPane.LEFT,JTabbedPane.SCROLL_TAB_LAYOUT);
    editTView editTView =new editTView();
    keshe2.edit.editTesterView editTesterView=new editTesterView();
    editAdView editAdView =new editAdView();
    editTAAView editTAAView =new editTAAView();
    @Override
    public void actionPerformed(ActionEvent e) {
        init();
        addAction();
        View.jf.setVisible(false);
        ControlCount.jf.setVisible(false);
        ControlDelete.jf.setVisible(false);
        ControlShow.jf.setVisible(false);
        ControlQuery.jf.setVisible(false);
    }
    public void addAction(){
        query.addActionListener(new ControlQuery());     //查询
        show.addActionListener(new ControlShow());       //显示
        edit.addActionListener(new ControlEdit());       //编辑
        delete.addActionListener(new ControlDelete());   //删除
        count.addActionListener(new ControlCount());     //统计
    }
    public void init(){
        jToolBar.add(add);
        jToolBar.add(query);
        jToolBar.add(show);
        jToolBar.add(edit);
        jToolBar.add(delete);
        jToolBar.add(count);
        jf.add(jToolBar, BorderLayout.NORTH);

        jtp.addTab("教师", editTView);
        jtp.addTab("实验员", editTesterView);
        jtp.addTab("行政人员", editAdView);
        jtp.addTab("教师兼行政人员", editTAAView);
        jf.setLocation(600,400);
        jf.add(jtp);
        jf.pack();
        jf.setVisible(true);
    }

    public static class HandleEditAdministrator implements ActionListener {
        editAdView editAdView;
        ReverseInformation reverseInformation=new ReverseInformation();

        @Override
        public void actionPerformed(ActionEvent e) {
            String sql= editAdView.t.getText();
            int isOK= reverseInformation.reverse(sql);
            if(sql.length()==0) return;
            if(isOK!=0){
                JOptionPane.showMessageDialog(editAdView,"修改成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(editAdView,"修改失败，该行政人员不存在或SQL语句错误！","提示",JOptionPane.WARNING_MESSAGE);
            }
            editAdView.t.setText("");
        }

        public void setView(editAdView editAdView){
            this.editAdView = editAdView;
        }
    }

    public static class HandleEditTeacher implements ActionListener {
        editTView editTView;
        ReverseInformation reverseInformation =new ReverseInformation();

        @Override
        public void actionPerformed(ActionEvent e) {
            String sql= editTView.t.getText();
            int isOK= reverseInformation.reverse(sql);
            if(sql.length()==0) return;
            if(isOK!=0){
                JOptionPane.showMessageDialog(editTView,"修改成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(editTView,"修改失败，该教师不存在或SQL语句错误！","提示",JOptionPane.WARNING_MESSAGE);
            }
            editTView.t.setText("");
        }

        public void setView(editTView editTView){
            this.editTView = editTView;
        }
    }

    public static class HandleEditTeacherAndAdministrator implements ActionListener {
        editTAAView editTAAView;
        ReverseInformation reverseInformation=new ReverseInformation();

        @Override
        public void actionPerformed(ActionEvent e) {
            String sql= editTAAView.t.getText();
            int isOK= reverseInformation.reverse(sql);
            if(sql.length()==0) return;
            if(isOK!=0){
                JOptionPane.showMessageDialog(editTAAView,"修改成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(editTAAView,"修改失败，该教师兼行政人员不存在或SQL语句错误！","提示",JOptionPane.WARNING_MESSAGE);
            }
            editTAAView.t.setText("");
        }

        public void setView(editTAAView editTAAView){
            this.editTAAView = editTAAView;
        }
    }

    public static class HandleEditTester implements ActionListener {
        keshe2.edit.editTesterView editTesterView;
        ReverseInformation reverseInformation=new ReverseInformation();
        @Override
        public void actionPerformed(ActionEvent e) {
            String sql=editTesterView.t.getText();
            int isOK= reverseInformation.reverse(sql);
            if(sql.length()==0) return;
            if(isOK!=0){
                JOptionPane.showMessageDialog(editTesterView,"修改成功！","提示",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(editTesterView,"修改失败，该实验员不存在或SQL语句错误！","提示",JOptionPane.WARNING_MESSAGE);
            }
            editTesterView.t.setText("");
        }

        public void setView(editTesterView editTesterView){
            this.editTesterView=editTesterView;
        }
    }
}
